Your song's audios (instrumental and voices) goes in song
Your song's scripts goes in scripts
Your song's charts goes in charts

Your charts has to have the name of it's respective difficulty. For example, the normal chart should either be named normal.json or normal.jsonc

If all of your charts uses the same metadata, you can seperate the metadata from your charts in it's own file (metadata.json / metadata.jsonc). Same goes for events (events.json / events.jsonc).